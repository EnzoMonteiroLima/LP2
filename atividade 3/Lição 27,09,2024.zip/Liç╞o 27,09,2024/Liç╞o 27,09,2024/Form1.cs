﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lição_27_09_2024
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(textBox1.Text, out LadoA))
            {
                errorProvider1.SetError(textBox1, "Entrada invalida, insira um numero");
                textBox1.Focus();
            }
            else
            {
                errorProvider1.SetError(textBox1, "");
            }


        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(textBox2.Text, out LadoB))
            {
                errorProvider2.SetError(textBox2, "Entrada invalida, insira um numero");
                textBox2.Focus();
            }
            else
            {
                errorProvider1.SetError(textBox2, "");
            }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(textBox3.Text, out LadoC))
            {
                errorProvider3.SetError(textBox3, "Entrada invalida, insira um numero");
                textBox3.Focus();
            }
            else
            {
                errorProvider1.SetError(textBox3, "");
            }
        }

        private void BtnIniciar_Click(object sender, EventArgs e)
        {
            if ((LadoA > Math.Abs(LadoB - LadoC)) && (LadoA < LadoB + LadoC) && (LadoB > Math.Abs(LadoA - LadoC)) && (LadoB < LadoA + LadoC) && (LadoC > Math.Abs(LadoA - LadoB)) && (LadoC < LadoA + LadoB))
            {
                MessageBox.Show("Triangulo valido");

                if ((LadoA == LadoB) && (LadoA == LadoC))
                {
                    MessageBox.Show("Seu triangulo é equilátero");
                }
                else
                {
                    if ((LadoA != LadoB) && (LadoA!= LadoC) && (LadoB != LadoC))
                    {
                        MessageBox.Show("Seu triangulo é escaleno");
                     
                    }
                    else
                    {
                        MessageBox.Show("Seu triangulo é isoceles");
                    }

                    
                }
                

            }
            else
            { MessageBox.Show("Triangulo invalido"); }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair :", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }
    }
}
 