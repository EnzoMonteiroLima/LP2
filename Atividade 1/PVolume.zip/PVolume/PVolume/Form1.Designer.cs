﻿namespace PVolume
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblRaio = new System.Windows.Forms.Label();
            this.LblAltura = new System.Windows.Forms.Label();
            this.LblResultado = new System.Windows.Forms.Label();
            this.BtnCalc = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.TxtRaio = new System.Windows.Forms.TextBox();
            this.TxtAltura = new System.Windows.Forms.TextBox();
            this.TxtResultado = new System.Windows.Forms.TextBox();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblRaio
            // 
            this.LblRaio.AutoSize = true;
            this.LblRaio.Location = new System.Drawing.Point(171, 55);
            this.LblRaio.Name = "LblRaio";
            this.LblRaio.Size = new System.Drawing.Size(42, 20);
            this.LblRaio.TabIndex = 0;
            this.LblRaio.Text = "Raio";
            this.LblRaio.Click += new System.EventHandler(this.label1_Click);
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(171, 122);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(51, 20);
            this.LblAltura.TabIndex = 1;
            this.LblAltura.Text = "Altura";
            this.LblAltura.Click += new System.EventHandler(this.label2_Click);
            // 
            // LblResultado
            // 
            this.LblResultado.AutoSize = true;
            this.LblResultado.Location = new System.Drawing.Point(171, 208);
            this.LblResultado.Name = "LblResultado";
            this.LblResultado.Size = new System.Drawing.Size(82, 20);
            this.LblResultado.TabIndex = 2;
            this.LblResultado.Text = "Resultado";
            this.LblResultado.Click += new System.EventHandler(this.LblResultado_Click);
            // 
            // BtnCalc
            // 
            this.BtnCalc.Location = new System.Drawing.Point(171, 364);
            this.BtnCalc.Name = "BtnCalc";
            this.BtnCalc.Size = new System.Drawing.Size(158, 87);
            this.BtnCalc.TabIndex = 3;
            this.BtnCalc.Text = "Calcular";
            this.BtnCalc.UseVisualStyleBackColor = true;
            this.BtnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(369, 364);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(161, 87);
            this.BtnSair.TabIndex = 4;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // TxtRaio
            // 
            this.TxtRaio.Location = new System.Drawing.Point(399, 52);
            this.TxtRaio.Name = "TxtRaio";
            this.TxtRaio.Size = new System.Drawing.Size(100, 26);
            this.TxtRaio.TabIndex = 1;
            this.TxtRaio.Validated += new System.EventHandler(this.TxtRaio_Validated);
            // 
            // TxtAltura
            // 
            this.TxtAltura.Location = new System.Drawing.Point(399, 122);
            this.TxtAltura.Name = "TxtAltura";
            this.TxtAltura.Size = new System.Drawing.Size(100, 26);
            this.TxtAltura.TabIndex = 2;
            this.TxtAltura.Validating += new System.ComponentModel.CancelEventHandler(this.TxtAltura_Validating);
            // 
            // TxtResultado
            // 
            this.TxtResultado.Location = new System.Drawing.Point(399, 202);
            this.TxtResultado.Name = "TxtResultado";
            this.TxtResultado.ReadOnly = true;
            this.TxtResultado.Size = new System.Drawing.Size(100, 26);
            this.TxtResultado.TabIndex = 3;
            this.TxtResultado.TextChanged += new System.EventHandler(this.TxtResultado_TextChanged);
            this.TxtResultado.Validated += new System.EventHandler(this.TxtResultado_Validated);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(569, 364);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(155, 87);
            this.BtnLimpar.TabIndex = 5;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1211, 668);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.TxtResultado);
            this.Controls.Add(this.TxtAltura);
            this.Controls.Add(this.TxtRaio);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnCalc);
            this.Controls.Add(this.LblResultado);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(this.LblRaio);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblRaio;
        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.Label LblResultado;
        private System.Windows.Forms.Button BtnCalc;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.TextBox TxtRaio;
        private System.Windows.Forms.TextBox TxtAltura;
        private System.Windows.Forms.TextBox TxtResultado;
        private System.Windows.Forms.Button BtnLimpar;
    }
}

