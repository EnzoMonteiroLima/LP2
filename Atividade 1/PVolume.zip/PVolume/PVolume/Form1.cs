﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TxtResultado_Validated(object sender, EventArgs e)
        {

        }

        private void TxtAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(TxtAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
                e.Cancel = true;
            }
            else if (altura <= 0)
            {
                MessageBox.Show("altura deve ser maior que zero");
                e.Cancel = true;
            }
            
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            resultado = Math.PI * Math.Pow(raio, 2) * altura;
            TxtResultado.Text = resultado.ToString("N2");

        }

        private void TxtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            TxtRaio.Text = "";
            TxtAltura.Text = string.Empty;
            TxtResultado.Clear();
        }

        private void LblResultado_Click(object sender, EventArgs e)
        {
            
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void TxtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtRaio.Text, out raio))
            {
                MessageBox.Show("Raio inválido!");
                TxtRaio.Focus();
            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("Raio deve ser maior que zero");
                    TxtRaio.Focus();
                }
            }
        }
    }
}
