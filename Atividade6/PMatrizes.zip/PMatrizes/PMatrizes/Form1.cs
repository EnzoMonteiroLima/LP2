﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            //string saida = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}°", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número invalido!");
                    i--;
                }
                //else
                //{
                 //   saida = auxiliar + "\n" + saida ;
                //}
                //MessageBox.Show(saida);

            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int i in  vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show (auxiliar);
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "joão", "pedro", "maria", "otavio" };
            lista.Remove("otavio");

            string ListaString = string.Join (",", lista.ToArray());
            MessageBox.Show("listaString");
            
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            Double[,] Notas = new Double[20, 3];
            String Auxiliar;
            Double[] Media = new Double[20];
            for(int aluno = 0; aluno < 20; aluno++)
                for (int  nota = 0; nota<3;nota++)
                {

                    Auxiliar = Interaction.InputBox("digite");
                    if (!Double.TryParse(Auxiliar, out Notas[aluno,nota]))
                    {
                        nota--;
                    }
                    else
                    {
                        if ((Notas[aluno, nota] < 0)||(Notas[aluno, nota] > 10))
                        {
                            nota--;
                        }
                        else { Media[aluno] = Notas[aluno, nota] + Media[aluno]; }
                          
                    }
                }
           
        }

        private void Btn4_Click(object sender, EventArgs e)
        {

        }

        private void Btn5_Click(object sender, EventArgs e)
        {

        }
    }
}
