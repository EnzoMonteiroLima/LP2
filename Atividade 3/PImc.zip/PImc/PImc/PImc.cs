﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PImc
{
    public partial class PImc : Form
    {
        Double Peso, Imc, Altura;


        public PImc()
        {
            InitializeComponent();
        }

        private void CalcularBtn_Click(object sender, EventArgs e)
        {
            Imc = Peso/Math.Pow(Altura,2); 

            Imc = Math.Round(Imc,1);
            IMCTxt.Text = Imc.ToString();

            if (Imc < 18.5)
            {
                MessageBox.Show("Classificação:Magreza");
            }
            else
                if(Imc<=24.9)
            {
                MessageBox.Show("Classificação:Normal");
            }
            else
                if (Imc <= 29.9)
            {
                MessageBox.Show("Classificação:Sobrepeso");
            }
            else
                if (Imc <= 39.9)
            {
                MessageBox.Show("Classificação:Obesidade");
            }
            else
                if (Imc >39.9)
            {
                MessageBox.Show("Classificação:Obesidade Grave");
            }
        }

        private void LimparBtn_Click(object sender, EventArgs e)
        {
            PesoMaskedTxt.Clear();
            AlturaMaskedTxt.Clear();
            IMCTxt.Clear();
        }

        private void SairBtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo:", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void PesoMaskedTxt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void AlturaMaskedTxt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void IMCTxt_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void PesoLbl_Click(object sender, EventArgs e)
        {

        }

        private void PesoMaskedTxt_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(PesoMaskedTxt.Text, out Peso))
            {
                errorProvider1.SetError(PesoMaskedTxt, "Peso invalido");
                PesoMaskedTxt.Focus();
            }
            else
             if (Peso <= 0) 
                {
                    errorProvider1.SetError(PesoMaskedTxt, "Peso deve ser superior a 0");
                }
            else
                {
                    errorProvider1.SetError(PesoMaskedTxt, "");
                }
            
        }

        private void AlturaMaskedTxt_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(AlturaMaskedTxt.Text, out Altura))
            {
                errorProvider2.SetError(PesoMaskedTxt, "Altura invalida");
                PesoMaskedTxt.Focus();
            }
            else
            if (Altura <= 0)
            {
                errorProvider2.SetError(PesoMaskedTxt, "Altura deve ser superior a 0");
            }
            else
            {
                errorProvider2.SetError(PesoMaskedTxt, "");
            }

        }

        private void AlturaLbl_Click(object sender, EventArgs e)
        {

        }

        private void IMCLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
