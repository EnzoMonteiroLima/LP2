﻿namespace PImc
{
    partial class PImc
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PesoLbl = new System.Windows.Forms.Label();
            this.AlturaLbl = new System.Windows.Forms.Label();
            this.IMCLabel = new System.Windows.Forms.Label();
            this.CalcularBtn = new System.Windows.Forms.Button();
            this.LimparBtn = new System.Windows.Forms.Button();
            this.SairBtn = new System.Windows.Forms.Button();
            this.PesoMaskedTxt = new System.Windows.Forms.MaskedTextBox();
            this.AlturaMaskedTxt = new System.Windows.Forms.MaskedTextBox();
            this.IMCTxt = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // PesoLbl
            // 
            this.PesoLbl.AutoSize = true;
            this.PesoLbl.Location = new System.Drawing.Point(108, 84);
            this.PesoLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PesoLbl.Name = "PesoLbl";
            this.PesoLbl.Size = new System.Drawing.Size(57, 13);
            this.PesoLbl.TabIndex = 0;
            this.PesoLbl.Text = "Peso atual";
            this.PesoLbl.Click += new System.EventHandler(this.PesoLbl_Click);
            // 
            // AlturaLbl
            // 
            this.AlturaLbl.AutoSize = true;
            this.AlturaLbl.Location = new System.Drawing.Point(108, 128);
            this.AlturaLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.AlturaLbl.Name = "AlturaLbl";
            this.AlturaLbl.Size = new System.Drawing.Size(34, 13);
            this.AlturaLbl.TabIndex = 1;
            this.AlturaLbl.Text = "Altura";
            this.AlturaLbl.Click += new System.EventHandler(this.AlturaLbl_Click);
            // 
            // IMCLabel
            // 
            this.IMCLabel.AutoSize = true;
            this.IMCLabel.Location = new System.Drawing.Point(108, 178);
            this.IMCLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.IMCLabel.Name = "IMCLabel";
            this.IMCLabel.Size = new System.Drawing.Size(26, 13);
            this.IMCLabel.TabIndex = 2;
            this.IMCLabel.Text = "IMC";
            this.IMCLabel.Click += new System.EventHandler(this.IMCLabel_Click);
            // 
            // CalcularBtn
            // 
            this.CalcularBtn.Location = new System.Drawing.Point(182, 206);
            this.CalcularBtn.Name = "CalcularBtn";
            this.CalcularBtn.Size = new System.Drawing.Size(73, 23);
            this.CalcularBtn.TabIndex = 3;
            this.CalcularBtn.Text = "Calcular";
            this.CalcularBtn.UseVisualStyleBackColor = true;
            this.CalcularBtn.Click += new System.EventHandler(this.CalcularBtn_Click);
            // 
            // LimparBtn
            // 
            this.LimparBtn.Location = new System.Drawing.Point(286, 206);
            this.LimparBtn.Name = "LimparBtn";
            this.LimparBtn.Size = new System.Drawing.Size(87, 23);
            this.LimparBtn.TabIndex = 4;
            this.LimparBtn.Text = "Limpar";
            this.LimparBtn.UseVisualStyleBackColor = true;
            this.LimparBtn.Click += new System.EventHandler(this.LimparBtn_Click);
            // 
            // SairBtn
            // 
            this.SairBtn.Location = new System.Drawing.Point(392, 206);
            this.SairBtn.Name = "SairBtn";
            this.SairBtn.Size = new System.Drawing.Size(75, 23);
            this.SairBtn.TabIndex = 5;
            this.SairBtn.Text = "Sair";
            this.SairBtn.UseVisualStyleBackColor = true;
            this.SairBtn.Click += new System.EventHandler(this.SairBtn_Click);
            // 
            // PesoMaskedTxt
            // 
            this.PesoMaskedTxt.Location = new System.Drawing.Point(207, 84);
            this.PesoMaskedTxt.Mask = "990.00";
            this.PesoMaskedTxt.Name = "PesoMaskedTxt";
            this.PesoMaskedTxt.Size = new System.Drawing.Size(100, 20);
            this.PesoMaskedTxt.TabIndex = 6;
            this.PesoMaskedTxt.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.PesoMaskedTxt_MaskInputRejected);
            this.PesoMaskedTxt.Validating += new System.ComponentModel.CancelEventHandler(this.PesoMaskedTxt_Validating);
            // 
            // AlturaMaskedTxt
            // 
            this.AlturaMaskedTxt.Location = new System.Drawing.Point(207, 128);
            this.AlturaMaskedTxt.Mask = "0.00";
            this.AlturaMaskedTxt.Name = "AlturaMaskedTxt";
            this.AlturaMaskedTxt.Size = new System.Drawing.Size(100, 20);
            this.AlturaMaskedTxt.TabIndex = 7;
            this.AlturaMaskedTxt.Validating += new System.ComponentModel.CancelEventHandler(this.AlturaMaskedTxt_Validating);
            // 
            // IMCTxt
            // 
            this.IMCTxt.Location = new System.Drawing.Point(207, 171);
            this.IMCTxt.Name = "IMCTxt";
            this.IMCTxt.ReadOnly = true;
            this.IMCTxt.Size = new System.Drawing.Size(100, 20);
            this.IMCTxt.TabIndex = 8;
            this.IMCTxt.TextChanged += new System.EventHandler(this.IMCTxt_TextChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // PImc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(613, 330);
            this.Controls.Add(this.IMCTxt);
            this.Controls.Add(this.AlturaMaskedTxt);
            this.Controls.Add(this.PesoMaskedTxt);
            this.Controls.Add(this.SairBtn);
            this.Controls.Add(this.LimparBtn);
            this.Controls.Add(this.CalcularBtn);
            this.Controls.Add(this.IMCLabel);
            this.Controls.Add(this.AlturaLbl);
            this.Controls.Add(this.PesoLbl);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "PImc";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PesoLbl;
        private System.Windows.Forms.Label AlturaLbl;
        private System.Windows.Forms.Label IMCLabel;
        private System.Windows.Forms.Button CalcularBtn;
        private System.Windows.Forms.Button LimparBtn;
        private System.Windows.Forms.Button SairBtn;
        private System.Windows.Forms.MaskedTextBox PesoMaskedTxt;
        private System.Windows.Forms.MaskedTextBox AlturaMaskedTxt;
        private System.Windows.Forms.TextBox IMCTxt;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
    }
}

