﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtBox2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(TxtBox2, "");
                numero2 = Convert.ToDouble(TxtBox2.Text);
            }
            catch (Exception)
            {
                errorProvider2.SetError(TxtBox2, "numero 2 inválido");
            }
        }

        private void BtnPlus_Click(object sender, EventArgs e)
        {
            TxtBox3.Clear();
            if(!Double.TryParse(TxtBox1.Text,out numero1)||
               !Double.TryParse(TxtBox2.Text,out numero2))
            {
                TxtBox1.Focus();
            }
            else
            {
                resultado = numero1+ numero2;
                TxtBox3.Text = resultado.ToString();
            }




        }

        private void BtnMinus_Click(object sender, EventArgs e)
        {
            TxtBox3.Clear();
            if(!Double.TryParse(TxtBox1.Text, out numero1)||
               !Double.TryParse(TxtBox2.Text, out numero2))
            { 
                TxtBox1.Focus();
            }
            else
            {
                resultado = numero1 - numero2;
                TxtBox3.Text = resultado.ToString();
            }

        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            TxtBox3.Clear();
            if(!Double.TryParse(TxtBox1.Text,out numero1)||
               !Double.TryParse(TxtBox2.Text,out numero2))
            {
                TxtBox1.Focus();
            }
            else
            {
                resultado = numero1 * numero2;
                TxtBox3.Text = resultado.ToString();
            }
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            TxtBox3.Clear();
            if(!Double.TryParse(TxtBox1.Text,out numero1)||!Double.TryParse(TxtBox2.Text,out numero2))
            {
                TxtBox1.Focus();
            }
            else
            {
                if (numero2 == 0)
                {
                    errorProvider2.SetError(TxtBox2, "Não é possivel dividir por 0");
                    TxtBox2.Focus();
                }
                else
                {
                    resultado = numero1 / numero2;
                    TxtBox3.Text = resultado.ToString();
                }
            }
        }

        private void TxtBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você deseja sair mesmo:","Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes)
            {
                Close();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtBox1.Clear();
            TxtBox2.Clear();
            TxtBox3.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TxtBox1_Validated(object sender, EventArgs e) 
        {
            if(!Double.TryParse(TxtBox1.Text, out numero1))  
            {
                errorProvider1.SetError(TxtBox1, "Número 1 inválido");
            }
            else
                errorProvider1.SetError(TxtBox1, "");
        }
        
    }
}
